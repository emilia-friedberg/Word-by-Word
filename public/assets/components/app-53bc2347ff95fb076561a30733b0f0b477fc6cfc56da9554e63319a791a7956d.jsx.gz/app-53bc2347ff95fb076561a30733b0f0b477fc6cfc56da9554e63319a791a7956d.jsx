class App extends React.Component {

  render() {
    return (
      <div>
        <p>this is the home app component</p>
      </div>
    )
  }
}
